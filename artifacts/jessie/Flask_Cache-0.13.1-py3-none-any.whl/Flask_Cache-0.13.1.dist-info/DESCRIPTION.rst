
Flask-Cache
-----------

Adds cache support to your Flask application



