"""Observer pattern."""
from .signal import Signal

__all__ = ('Signal',)
